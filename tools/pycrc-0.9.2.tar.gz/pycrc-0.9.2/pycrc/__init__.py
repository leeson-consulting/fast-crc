progname = "pycrc"
version = "0.9.2"
url = 'https://pycrc.org'
